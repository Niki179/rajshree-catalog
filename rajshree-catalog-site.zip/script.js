
let cart = [];
function addToCart() {
    cart.push("Fancy Bangles Set");
    updateCart();
}
function updateCart() {
    const cartList = document.getElementById("cartItems");
    cartList.innerHTML = "";
    cart.forEach(item => {
        const li = document.createElement("li");
        li.textContent = item;
        cartList.appendChild(li);
    });
}
function checkout() {
    alert("Thank you for your interest! Checkout will be added soon.");
}
